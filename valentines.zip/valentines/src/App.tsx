import { useState } from 'react';
import './App.css';

// importa os GIFs locais
import stitchLonely from './assets/stitch-lonely.gif';
import stitchAngel from './assets/stitch-angel.gif';

function App() {
  const [yesClicked, setYesClicked] = useState(false);
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [scale, setScale] = useState(1);

  const handleNoHover = () => {
    const randomX = Math.random() * 200 - 100;
    const randomY = Math.random() * 200 - 100;
    setNoPosition({ x: randomX, y: randomY });
  };

  const handleYesClick = () => {
    setYesClicked(true);
    setScale(1.2);
    createConfetti();
  };

  const createConfetti = () => {
    for (let i = 0; i < 30; i++) {
      const confetti = document.createElement('div');
      confetti.className = 'confetti';
      confetti.style.left = Math.random() * 100 + '%';
      confetti.style.animationDelay = Math.random() * 0.3 + 's';
      document.body.appendChild(confetti);

      setTimeout(() => confetti.remove(), 3000);
    }
  };

  const resetAll = () => {
    setYesClicked(false);
    setScale(1);
    setNoPosition({ x: 0, y: 0 });
  };

  return (
    <div className="container">
      {!yesClicked ? (
        <div className="card">
          <div className="image-container">
            {/* Stitch lonely a perguntar */}
            <img
              src={stitchLonely}
              alt="Stitch sozinho e carente"
              className="minion-image"
            />
          </div>

          <h1 className="question">
            Queres ser a minha Valentine? 💙
          </h1>

          <div className="buttons-container">
            <button
              className="button yes-button"
              onClick={handleYesClick}
              style={{ transform: `scale(${scale})` }}
            >
              Sim 💗
            </button>

            <button
              className="button no-button"
              onMouseEnter={handleNoHover}
              style={{
                transform: `translate(${noPosition.x}px, ${noPosition.y}px)`
              }}
            >
              Não
            </button>
          </div>
        </div>
      ) : (
        <div className="card">
          <div className="image-container">
            {/* Stitch + Angel juntos */}
            <img
              src={stitchAngel}
              alt="Stitch e Angel juntos"
              className="minion-image"
            />
          </div>

          <h1 className="question">
            YAY! Agora somos Valentines 💙💗
          </h1>
          <p className="success-text">
            Amo-te muito, obrigado por dizeres Sim!
          </p>

          <button
            className="button reset-button"
            onClick={resetAll}
          >
            Ver de novo ↻
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
